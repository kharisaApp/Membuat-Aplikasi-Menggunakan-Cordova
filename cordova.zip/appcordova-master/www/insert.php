<?php
 include "db.php";
 if(isset($_POST['insert']))
 {
 $title=$_POST['Nama'];
 $duration=$_POST['Alamat'];
 $price=$_POST['ID'];
 $q=mysqli_query($con,"INSERT INTO `course_details` (`Nama`,`Alamat`,`ID`) VALUES ('$Nama','$Alamat','$ID')");
 if($q)
  echo "success";
 else
  echo "error";
 }
 ?>
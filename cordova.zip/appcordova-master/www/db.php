<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","id12804492_umami","kharisa17","id12804492_risa") or die ("could not connect database");
?>
<?php
 include "db.php";
 if(isset($_POST['update']))
 {
 $id=$_POST['Nama'];
 $title=$_POST['Alamat'];
 $duration=$_POST['ID'];
 $q=mysqli_query($con,"UPDATE `course_details` SET `Nama`='$Nama',`Alamat`='$Alamat',`ID`='$ID' where `ID`='$ID'");
 if($q)
 echo "success";
 else
 echo "error";
 }
 ?>